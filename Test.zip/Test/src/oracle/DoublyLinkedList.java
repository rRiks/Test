package oracle;

public class DoublyLinkedList<E>
{

	Node<E> head=null;
	public static void main(String[] args)
	{
		DoublyLinkedList list = new DoublyLinkedList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		
		printElement(list);
		list.remove(2);
		printElement(list);
	}
	
	public static void printElement(DoublyLinkedList list) {
		Node node = list.head;
		while(node!=null) {
			System.out.println(node.element);
			node = node.next;
		}
	}
	
	public void add(E element) {
		Node<E> newNode =  new Node<E>(element);
		if(head==null) {
			head = newNode;
		}else {
			Node<E> currNode = head;
			while(currNode.next!=null) {
				currNode = currNode.next;
			}
			newNode.prev = currNode;
			currNode.next = newNode; 
		}
	}
	
	public void remove(E element) {
		Node curNode = head;
		while(curNode!=null) {
			if(curNode.element==element && curNode.prev!=null) {
				curNode.prev.next = curNode.next;
				break;
			}else if(curNode.element==element) {
				head = curNode.next;
				break;
			}
			curNode = curNode.next;
		}
		
	}
	
	
	
	
	public static class Node<E>{
		E element;
		Node prev;
		Node next;
		Node(E element){
			this.element=element;
		}
	}

}
