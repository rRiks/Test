package oracle;

public class Stack
{
	
	private int[] arr;
	private int top;
	private int capacity;
	
	//constructor to initialize the stack
	Stack(int size){
		arr = new int[size];
		capacity = size;
		top=-1;
	}
	
	//Utility function 
	public void push(int element) {
		if(isFull()) {
			System.out.println("Overflow\nProgram Terminated\n");
            System.exit(1);
		}
		arr[++top]=element;
		
	}
	
	//utility function to pop a element
	public int pop(int element) {
		if(isEmpty()) {
			System.out.println("Underflow\nProgram Terminated");
            System.exit(1);
		}
		return arr[top--];
	}
	
	// Utility function to return the top element of the stack
    public int peek()
    {
        if (!isEmpty()) {
            return arr[top];
        }
        else {
            System.exit(1);
        }
 
        return -1;
    }
	
	public boolean isEmpty() {
		return top==-1?true:false;
	}

	public boolean isFull() {
		return top==capacity-1?true:false;
	}
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}
