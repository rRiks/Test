package oracle;


public class SingleLinkedListRemoval<E>
{

	public  Node<E> node;
	public static void main(String[] args)
	{
		SingleLinkedListRemoval<Integer> list = new SingleLinkedListRemoval();
		list.add(1);
		list.add(2);
		list.add(3);
		print(list);
		list.remove(2);
		print(list);
		
		
	}

	public static void printNodes(Node<?> node) {
		if(node!=null) {
			System.out.println("Element "+ String.valueOf(node.data));
		}
		if(node.next!=null) {
			printNodes(node.next);
		}
		
	}
	
	public static void print(SingleLinkedListRemoval list) {
		Node currNode = list.node;
		while(currNode!=null) {
			System.out.println(currNode.data);
			currNode = currNode.next;
		}
		
	}
	
	public void add(E element) {
		Node<E> new_node = new Node<E>(element);
		if(node==null){
			node = new_node;
		}else {
			Node curr_node = node;
			while(curr_node.next!=null) {
				curr_node = curr_node.next;
			}
			curr_node.next = new_node;
		}
	}
	
	
	public void remove(E element) {
		Node currNode = this.node;
		Node prevNode = null;
		while(currNode!=null) {
			if(currNode.data == element && prevNode == null) {
				currNode = null;
				break;
			}else if(currNode.data == element) {
				prevNode.next = currNode.next;
				break;
			}
			prevNode = currNode;
			currNode = currNode.next;
		}
	}
	
	
	static class Node<E>{
		
		E data;
		Node<E> next;
		public Node(E data){
			this.data = data;
			this.next = null;
		}		
	}
}
