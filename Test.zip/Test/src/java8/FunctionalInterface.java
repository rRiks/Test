package java8;

import java.util.List;
import java.util.function.Predicate;

public class FunctionalInterface
{

	public static void main(String[] args)
	{
		

	}
	
	public static void eval(List<Integer> list,Predicate<Integer> predicate) {
		list.forEach(predicate::test);
	}

}
