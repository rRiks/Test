package java8;

public class LambdaExpression
{

	public static void main(String[] args)
	{
		MathOperation addition = (int a, int b) ->{ int d = a + b; System.out.println(d);return d;};
		addition.operation(3, 4);
	}
}

interface MathOperation {
    int operation(int a, int b);
 }
	
 interface GreetingService {
    void sayMessage(String message);
 }