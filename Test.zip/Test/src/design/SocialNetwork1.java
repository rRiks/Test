package design;
/*We are designing the public HTTP API for a web service that helps corporate social media managers post to multiple social media networks at once (such as Facebook, Twitter, or LinkedIn). Our product has a few use cases:

	  1. Create a new post on one social network
	  2. Create a new post across multiple social networks
	  3. Provide statistics to show how users interacted with a post
	  4. Delete an existing post

	What should be the methods of our API? Give each method a name, and specify the fields of its request and response messages.

	For now, we'll assume that your API works 100% of the time and never encounters an error.


	Write your answers like this sample API method - note, you do not need to address specific GET/POST/DELETE semantics:

	Method: GetShippingStatus
	Request fields:
	    Tracking number (string)
	Response fields:
	    Status message (string)
	    Expected delivery date (date)
	    */

public class SocialNetwork1
{
	 /*Method(Post): addMessage
	Security Header(Authorization): JWT token (string)
	idempotency:idempotetnt key
	RequestFields:
		MultiPartFormData:
			userId: integer
			message (string)
			file (MultiPartFile)
			socialMediaId: String
	ResponseFields:
		messageId:ineteger
		message_key (success message key)
		message_value (localized value)
		status code(integer)
		socialMediaId: String
		
	/*Method: addMessage
	
		arrSocialMediaId: Array
	
	 */
	
	
	/* Security Header(Authorization): JWT token (string)
	 * Method(GET): getStatistics
	 *  requestParam:
	 *  	userId (integer)
	 *  	messageId (integer)
	 *  ResponseFields:
	 *  	status
	 *  	likes: integer
	 *  	views: integer
	 *  	love: integer
	 * 
	 * */
	
	/* Method (DELETE) : deletePost
	 * 	pathParam:userId(integer) and messageId (integer)
	 * ResponseFields:
	 * 	messageId:ineteger
		message_key (success message key)
		message_value (localized value)
		status code(inetger)
	 * 	
	 * 
	 */
	
	//Now that you've defined the API, let's think about error handling. Identify some cases where this API could fail and what you should do in each case.
	//1. 400 Bad request
	//2. 500 internal server error
	//3. 401 Unautjorized access
	
	/*We have a new requirement -- we want users to be able to upload images and video to our API server and re-use those videos across multiple posts and social media platforms. 
	We also want to support media-only posts with no text. How would you change your API while still supporting your existing users? */
		

}
