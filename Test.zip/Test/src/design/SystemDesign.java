package design;

public class SystemDesign
{
	/**
	 * Scaling An Operation
	 * --------------------------
	 * We are working on a clone of Facebook. We want to add a numeric count to every post showing how many friends the post's author has at the time of viewing the post, like this:

Marie McWilliams (105 friends)
I had a great day today, feeling good!

Right now, our database has two tables:


USER
  'user_id' (primary key)
  'name'
  'created_date'

USER_RELATIONSHIP
  'friendship_id' (primary key, unique to each relationship)
  'user1_id' (indexed)
  'user2_id' (indexed)
  'start_date'
Focusing on the database, how would you implement the friend-count feature? Note we will soon be more popular than Facebook, so the solution needs to scale. (Check only one.)

Solutions:
------------------
Basic: Use a normal SELECT query, with or without joins, to gather the friend count.

Basic: Use a foreign key constraint to gather the friend count.

Basic: Cache the database query, updating the cache on a timer or via an expiry method and re-querying when updating.

Intermediate: Denormalize the database by storing the list of friendships directly on the user record.

Intermediate: Add a �friendship_count� to the user table and update it synchronously.

Intermediate: Use a graph-based datastore (e.g., Weaver) to represent the social network and track vertex edge counts.

Advanced: Add a �friendship_count� to the user table and update it asynchronously.


	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	
	/** 
	 * Load Balancing
	 * -------------------------
	 * 
	 * We have a fixed number of servers which will be sufficient to handle our expected load, if used properly.  

Our load balancer uses a round-robin system to permanently assign documents to each server, so each server will have an equal number of documents.

Do you have any concerns about this load balancing system?

Solution:

Problem 1: Traffic will not be evenly distributed over time between documents, so some servers will be over-utilized while others are under-utilized.

Problem 2: Since there is a permanent affinity between documents and servers, servers have no ability to �load shed� � if a server�s resources are oversubscribed, other documents bound to that server will also exhibit poor performance indefinitely.

Basic solution characteristics: Create a new service (or reconfigure the load balancer) to provide floating �affinity� at the load-balancing layer by assigning each document to an instance and making reassignment possible. This can be accomplished with a simple cache or something more sophisticated like a distributed hash or a third-party tool. May include simple balancing based on the number of documents active on a given machine.

Advanced solution characteristics: In addition to floating affinity, the load-balancer should use performance metrics to make decisions about where to send a document. If a document is not currently loaded, assign it to the instance with the lowest load. Route traffic away from instances that appear to be failing (i.e., they don�t respond to a health check).

	 * 
	 * 
	 * */

	
	/**
	 * Consistency
	 * ---------------------
	 * Which consistency model is more appropriate for each of these applications: strong consistency, or eventual consistency? Why?

An API call that needs to respond within 20 milliseconds, used by a web service to retrieve metadata about a piece of streaming media.
A web analytics platform recording every single click on a web page
A banking system that makes deposits and payments to checking accounts


Solution:
--------------
API call: Eventual consistency - Basic: It is acceptable for the metadata to be out of date, so eventual consistency is an acceptable model.

API call: Eventual consistency - Advanced: Services with �high availability� requirements, such as a tight time-bound SLA or five-nines availability, almost always prefer eventual consistency to avoid network bottlenecks that would make their SLAs unrealistic.

Analytics platform: Eventual consistency - Basic: Eventual consistency is fine for this system as the analytics reports don�t need to be up-to-date with all of the latest data.

Analytics platform: Eventual consistency - Advanced: A discussion about scalability concerns (fast writes, caching, horizontal scaling). Basically, making this system strongly consistent would make it difficult to scale out to handle all of the write requests.

Banking system: Strong consistency - Basic: It is more important for bank transactions to be consistent than fast.

Banking system: Strong consistency - Advanced: Every reader of bank account data should see the same view of the data so that they can make correct/consistent decisions.


	 * 
	 * */
	/**
	 * Data
	 * -----------------
	 * We maintain a distributed system that allows users to "e-sign" legal documents. After a document is fully signed, the owner gets an email notification. A document may need hundreds of signatures in order to be fully signed.

We recently had a bug that caused the notifications to fail (about 50% of the time) over the course of a week. We have two pieces of information:

A database table that records whether the document is fully signed or not.
Flat-file logs from our 500 production servers. We log the ID of a document when we send out a notification, so the failed notifications are missing from these logs.
How can you use the logs and database to find all the missed notifications? The service handles hundreds of millions of documents per day, so we need a scalable solution. (Check only one.)
	 * 
	 * 
	 * 
	 * Solutions:
	 * -------------
	 * Basic: Make an in-memory list of all document IDs that have been fully signed (without MapReduce, Hadoop, or any other distributed computation) and compare it to the logged notifications.

Intermediate: Create a temporary database table with an entry for each document, use a single process to read the logs to backfill a �notification sent� state column in the table, and join it to the signed status in the original database to build the list of notifications that need to be sent.

Intermediate: Make an in-memory set of all document IDs that have been fully signed. Process the logs in parallel (using any distributed computation framework) to build the set of sent notifications. Compute the difference of these two datasets in memory to determine the list of notifications that need to be re-sent.

Advanced: Run a MapReduce (or use another distributed computation framework, such as Hadoop, Apache Spark, or even build a simple tool to distribute work across multiple machines) that builds the set of sent notifications in parallel, joins the database table to the that set, and finds all documents that were fully signed but that did not result in a notification being sent.
	 */
	

	
	
	
	/**
	 * Bottleneck
	 * -----------------------
	 * Our company has suffered a security breach, and the credit card numbers of millions of our users were exposed.

We've built a cascading and distributed pipeline to notify the users about the problem.


                                 +--+
                                 |G |
                             +-> |25|
                             |   +--+
+--+       +--+       +--+   |
|A |       |B |       |C |   |
|50| ----> |30| -+--> |30| -->
+--+       +--+  |    +--+   |   +--+       +--+
                 |           |   |E |       |F |
                 |    +--+   +-> |10| ----> |20|
                 +--> |D |       +--+       +--+
                      |90|
                      +--+
The number below each stage of the graph shows how many records it can process per second.
A record is considered processed when it goes through every single step of the pipeline.
What is the maximum throughput of this pipeline, as a whole? (Check all that apply.)

FOLLOW UP QUESTION
Now that you've identified the bottleneck, if you wanted to reduce the total time needed to process your data set, how would you start to optimize the pipeline? The function of each step is shown below.

Stage A: Read from a large data source of credit card numbers

Stage B: Check card numbers for validity

Stage C: Look up the user ID for each credit card number in datastore 1

Stage D: Write summary of each record to a log file

Stage E: Look up the email address for each user ID in datastore 2

Stage F: Send an email with user info

Stage G: Write affected credit card number to a new MySQL database

Answers
Throughput: Because Stage E is the bottleneck, the throughput of the entire pipeline is 10 records / second.

Follow-up answer 1: Horizontally scaling Stage E can help, by parallelizing computation across more machines.

Follow-up answer 2: The database could be the bottleneck. If so, use caching to reduce the number of calls at Stage E. Or, dump the keys/values from the datastore to disk and shard the data for faster lookups. Or add more resources to the database.
	 * 
	 * 
	 * */
}
