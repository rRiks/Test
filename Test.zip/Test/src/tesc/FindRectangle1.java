package tesc;
/*
Imagine we have an image. We'll represent this image as a simple 2D array where every pixel is a 1 or a 0.

The image you get is known to have potentially many distinct rectangles of 0s on a background of 1's. Write a function that takes in the image and returns the coordinates of all the 0 rectangles -- top-left and bottom-right; or top-left, width and height.
int row[][] = {2, 3};
image1 = [
  [0, 1, 1, 1, 1, 1, 1],
  [1, 1, 1, 1, 1, 1, 1],
  [0, 1, 1, 0, 0, 0, 1],
  [1, 0, 1, 0, 0, 0, 1],
  [1, 0, 1, 1, 1, 1, 1],
  [1, 0, 1, 0, 0, 1, 1],
  [1, 1, 1, 0, 0, 1, 1],
  [1, 1, 1, 1, 1, 1, 0],
]

[
  [[0, 0], [0, 0]],
  [[2, 0], [2, 0]],
  [[2, 3], [3, 5]],
  
]

Sample output variations (only one is necessary):

findRectangles(image1) =>
  // (using top-left-row-column and bottom-right):
  [
    [[0,0],[0,0]],
    [[2,0],[2,0]],
    [[2,3],[3,5]],
    [[3,1],[5,1]],
    [[5,3],[6,4]],
    [[7,6],[7,6]],
  ]
  // (using top-left-row-column and width/height):
  [
    [[0,0],[1,1]],
    [[2,0],[1,1]],
    [[2,3],[3,2]],
    [[3,1],[1,3]],
    [[5,3],[2,2]],
    [[7,6],[1,1]],
  ]

Other test cases:

image2 = [
  [0],
]

findRectangles(image2) =>
  // (using top-left-row-column and bottom-right):
  [
    [[0,0],[0,0]],
  ]

  // (using top-left-row-column and width/height):
  [
    [[0,0],[1,1]],
  ]

image3 = [
  [1],
]

findRectangles(image3) => []

image4 = [
  [1, 1, 1, 1, 1],
  [1, 0, 0, 0, 1],
  [1, 0, 0, 0, 1],
  [1, 0, 0, 0, 1],
  [1, 1, 1, 1, 1],
]

findRectangles(image4) =>
  // (using top-left-row-column, and bottom-right or width/height):
  [
    [[1,1],[3,3]],
  ]

n: number of rows in the input image
m: number of columns in the input image
*/

import java.util.Arrays;

public class FindRectangle1 {
    
  public static void main(String[] argv) {
    int[][] image1 = {
      {0, 1, 1, 1, 1, 1, 1},
      {1, 1, 1, 1, 1, 1, 1},
      {0, 1, 1, 0, 0, 0, 1},
      {1, 0, 1, 0, 0, 0, 1},
      {1, 0, 1, 1, 1, 1, 1},
      {1, 0, 1, 0, 0, 1, 1},
      {1, 1, 1, 0, 0, 1, 1},
      {1, 1, 1, 1, 1, 1, 0},
    };
    
   /* 		[[0, 0], [0, 0]]
    		[[2, 0], [2, 0]]
    		[[2, 3], [3, 5]]
    		[[3, 1], [3, 1]]
    		[[3, 4], [3, 4]]
    		[[5, 1], [5, 1]]
    		[[5, 3], [6, 4]]
    		[[7, 6], [7, 6]]*/

    int[][] image2 = {
      {0},
    };

    int[][] image3 = {
      {1},
    };

    int[][] image4 = {
      {1, 1, 1, 1, 1},
      {1, 0, 0, 0, 1},
      {1, 0, 0, 0, 1},
      {1, 0, 0, 0, 1},
      {1, 1, 1, 1, 1},
    };
    
    int [] []image5 = {
                             {1, 1, 1, 1, 1, 1, 1},
                             {1, 1, 1, 1, 1, 1, 1},
                             {1, 1, 1, 0, 0, 0, 1},
                             {1, 0, 1, 0, 0, 0, 1},
                             {1, 0, 1, 1, 1, 1, 1},
                             {1, 0, 1, 0, 0, 0, 0},
                             {1, 1, 1, 0, 0, 0, 1},
                             {1, 1, 1, 1, 1, 1, 1}
    };



    
    firstPosition(image5);
    
//     System.out.println(Arrays.deepToString(result));
  }
  
  public static void firstPosition(int[][] image){
		int totalRow = image.length;
		int totalCol = image[0].length;
		for (int row=0;row<totalRow;row++){

			for(int col=0;col<totalCol;col++){
				if(image[row][col] == 0){
					image[row][col] = 5;
					getRectangle(image,row,col);
				}
			}
		}

		}

		public static void getRectangle(int[][] image,int row,int col){
			int totalRow = image.length;
			int totalCol = image[0].length;
			int rowPosition = row;
			int colPosition = col;
			//int temprow = row;
			int tempcol = col;
			//Iterate the column
			while(col+1<totalCol){
				if(image[row][col+1]==0){
					image[row][col+1]=5;
					col++;
				}else{
					break;
				}
			
			}
			
			//Iterate rows
			while(row+1<totalRow){
				if(tempcol<=col) {
					if(image[row+1][tempcol]==0){
						image[row+1][tempcol]=5;
						/*if(tempcol==col) {
							tempcol = colPosition;
							row++;
						}else {*/
							tempcol++;
						//}
					}else{
						break;
					}
				}else {
					tempcol = colPosition;
					row++;
				}
				
			
			}
		System.out.println(new Rectangle(rowPosition,colPosition,row,col));	
		//System.exit(0);
		}

		}
		class Rectangle{

		int startRow;
		int startColumn;
		int endRow;
		int endColumn;

		Rectangle(int startRow,int startColumn,int endRow,int endColumn){
		 this.startRow = startRow;
		 this.startColumn = startColumn;
		 this.endRow = endRow;
		 this.endColumn = endColumn;
		}

		public String toString(){
			StringBuffer rectangleSB = new StringBuffer();
		rectangleSB.append("startRow: ");
		rectangleSB.append(String.valueOf(startRow));
		rectangleSB.append(" startColumn: ");
		rectangleSB.append(String.valueOf(startColumn));
		rectangleSB.append("      endRow:");
		rectangleSB.append(String.valueOf(endRow));
		rectangleSB.append(" endColumn: ");
		rectangleSB.append(String.valueOf(endColumn));

		return rectangleSB.toString();
		}
	}
  
 /* public static void addToMap(Map<Integer,List<Integer>> rowColumnVisitedMap,int row,int col) {
	  if(rowColumnVisitedMap!=null && rowColumnVisitedMap.containsKey(row)) {
		  rowColumnVisitedMap.get(row).add(col);
	  }else {
		  List<Integer> colList = new ArrayList<Integer>();
		  colList.add(col);
		  rowColumnVisitedMap.put(row,colList );
	  }
  }*/
  

