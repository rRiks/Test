package tesc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/*
Suppose we have some input data describing a graph of relationships between parents and children over multiple generations. The data is formatted as a list of (parent, child) pairs, where each individual is assigned a unique positive integer identifier.

For example, in this diagram, 3 is a child of 1 and 2, and 5 is a child of 4:

1   2    4   15
 \ /   / | \ /
  3   5  8  9
   \ / \     \
    6   7    11


Sample input/output (pseudodata):

parentChildPairs = [
    (1, 3), (2, 3), (3, 6), (5, 6), (15, 9),
    (5, 7), (4, 5), (4, 8), (4, 9), (9, 11)
]


Write a function that takes this data as input and returns two collections: one containing all individuals with zero known parents, and one containing all individuals with exactly one known parent.


Output may be in any order:

findNodesWithZeroAndOneParents(parentChildPairs) => [
  [1, 2, 4, 15],       // Individuals with zero parents
  [5, 7, 8, 11]        // Individuals with exactly one parent
]

Complexity Analysis variables:

n: number of pairs in the input

 */
public class ParentChild {
  public static void main(String[] argv) {

	  int[][] parentChildPairs = new int[][] {
	      {1, 3}, 
	      {2, 3}, 
	      {3, 6}, 
	      {5, 6}, 
	      {15, 9}, 
	      {5, 7}, 
	      {4, 5}, 
	      {4, 8}, 
	      {4, 9}, 
	      {9, 11}
	    };
	    getParentChildData(parentChildPairs);

  }
  
  private static void getParentChildData(int [][]inputData) {
	  int totalRow = inputData.length;
	  //int totalColumn = inputData[0].length;
	  Map<Integer,List<Integer>> parentChildMap = new HashMap<Integer, List<Integer>>();
	  for(int row=0;row<totalRow;row++) {
			  addToMap(inputData,row,parentChildMap);
	  }
	  addToList(parentChildMap);
  }
  
  private static void addToMap(int [][]inputData,int row,Map<Integer,List<Integer>> parentChildMap) {
	  if(!parentChildMap.containsKey(inputData[row][1])) {
		  parentChildMap.put(inputData[row][1], new ArrayList<Integer>());
	  }
	  List<Integer> tempData = parentChildMap.get(inputData[row][1]);
	  tempData.add(inputData[row][0]);
	  parentChildMap.put(inputData[row][1],tempData);
  }
  
  
  private static void addToList(Map<Integer,List<Integer>> parentChildMap) {
	  Set<Integer> parentList = new TreeSet<Integer>();
	  List<Integer> noParentList = new ArrayList<Integer>();
	  List<Integer> parentListOneParent = new ArrayList<Integer>();
	 for(Map.Entry<Integer,List<Integer>> entry: parentChildMap.entrySet()) {
		 if(entry.getValue()!=null && entry.getValue().size()==1) {
			 parentListOneParent.add(entry.getKey());
		 }
		 parentList.addAll(entry.getValue());
	 }
	 for(Integer parent : parentList) {
		 if(!parentChildMap.containsKey(parent)) {
			 noParentList.add(parent);
		 }
	 }
	 System.out.println(noParentList);
	 System.out.println(parentListOneParent);
  }
}
