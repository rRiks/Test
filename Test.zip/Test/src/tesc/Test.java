package tesc;

import java.util.*;


public class Test
{

	public static void main(String[] argv)
	{
		List<String> list = Arrays.asList("hello","test","test","hello","Java");
		System.out.println(wordFrequencyCount(list));
	}
		
	  
	/**
	 * This method is used to count the frequency of words present in a list
	 * @param data
	 * @return result
	 * */
	public static Map<String, Integer> wordFrequencyCount(List<String> data) {
	    Map<String, Integer> result = new HashMap<String, Integer>();
	    for (int i = 0; i < data.size(); i++) {
	    	result.put(data.get(i),result.getOrDefault(data.get(i),0)+1);
	    }
	    return result;
	}
		  

	


	

}

