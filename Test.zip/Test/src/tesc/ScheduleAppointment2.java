package tesc;

/*

We are writing a tool to help users manage their calendars. Given an unordered list of times of day when people are busy, 
write a function that tells us the intervals during the day when ALL of them are available.

Each time is expressed as an integer using 24-hour notation, such as 1200 (12:00), 1530 (15:30), or 800 (8:00).

Sample input:

p1_meetings = [
  (1230, 1300),
  ( 845, 900),
  (1300, 1500),
]

p2_meetings = [
  ( 0, 844),
  ( 930, 1200),
  (1515, 1546),
  (1600, 2400),
]

p3_meetings = [
  ( 845, 915),
  (1515, 1545),
  (1235, 1245),
]

p4_meetings = [
  ( 1, 5),
  (844, 900),
  (1515, 1600)
]

schedules1 = [p1_meetings, p2_meetings, p3_meetings]
schedules2 = [p1_meetings, p3_meetings]
schedules3 = [p2_meetings, p4_meetings]

Expected output:

findAvailableTimes(schedules1)
 => [  844,  845 ],
    [  915,  930 ],
    [ 1200, 1230 ],
    [ 1500, 1515 ],
    [ 1546, 1600 ]

findAvailableTimes(schedules2)
 => [    0,  845 ],
    [  915, 1230 ],
    [ 1500, 1515 ],
    [ 1545, 2400 ]

findAvailableTimes(schedules3)
    [  900,  930 ],
    [ 1200, 1515 ]

n = number of meetings
s = number of schedules


*/



import java.io.*;
import java.util.*;

public class ScheduleAppointment2 {
  public static void main(String[] argv) {
	  
	  int[][] p1Meetings = {
		      {1230, 1300},
		      { 845,  900},
		      {1300, 1500}
		    };
		    int[][] p2Meetings = {
		      { 0, 844},
		      { 930, 1200},
		      {1515, 1546},
		      {1600, 2400}
		    };
		    int[][] p3Meetings = {
		      { 845,  915},
		      {1515, 1545},
		      {1235, 1245}
		    };
		    int[][] p4Meetings = {
		      {   1,  5},
		      { 844, 900},
		      {1515, 1600}
		    };

		    List<int[][]> schedules1 = Arrays.asList(p1Meetings, p2Meetings, p3Meetings);
		    List<int[][]> schedules2 = Arrays.asList(p1Meetings, p3Meetings);
		    List<int[][]> schedules3 = Arrays.asList(p2Meetings, p4Meetings);
		    System.out.println(getAvailableTime(schedules1));
		    System.out.println(getAvailableTime(schedules2));
		    System.out.println(getAvailableTime(schedules3));
  }
  
  public static List<Employee> getAvailableTime(List<int[][]> scheduleList){
	  List<Employee> employeeList = new ArrayList<>();
	  for(int[][] schedule : scheduleList) {
		  for(int row=0;row<schedule.length;row++){
			  employeeList.add(new Employee(schedule[row][0],schedule[row][1]));
		  }
	  }
	  return getFreeTime(employeeList);
  }
  

public static List<Employee> getFreeTime(List<Employee> employeeList){
	List<Employee> listFreeTime = new ArrayList<>();
	List<Employee> mergedTime = new LinkedList<>();
	int minElement=0;
	int maxElement=0;
	Collections.sort(employeeList,new Comparator<Employee>() {
		public int compare(Employee e1,Employee e2) {
			return e1.startTime-e2.startTime;
		}
	});
	for(int index=0;index<employeeList.size();index++) {
		int startTime = employeeList.get(index).startTime;
		int endTime = employeeList.get(index).endTime;
		if(endTime>maxElement) {
			maxElement = endTime;
		}
		if(index==0) {
			minElement = startTime;
		}
		
		
		  if(index!=0 && 
				 startTime<mergedTime.get(mergedTime.size()-1).endTime &&
				 endTime> mergedTime.get(mergedTime.size()-1).endTime) { 
			  startTime = mergedTime.get(mergedTime.size()-1).startTime;
			  mergedTime.remove(mergedTime.size()-1);
		  }else if(index!=0 && mergedTime.get(mergedTime.size()-1).endTime>=endTime) {
			  continue;
		  }
		 
		mergedTime.add(new Employee(startTime,endTime));
	}
	
	  if(mergedTime.get(0).startTime>minElement) {
		  listFreeTime.add(new Employee(minElement,mergedTime.get(0).startTime)); 
		}
	 
	for(int count=0;count<mergedTime.size();count++) {
		if(count+1<mergedTime.size() && mergedTime.get(count).endTime !=mergedTime.get(count+1).startTime) {
			listFreeTime.add(new Employee(mergedTime.get(count).endTime,mergedTime.get(count+1).startTime));
		}
	}
	
	  if(mergedTime.get(mergedTime.size()-1).endTime<maxElement) { listFreeTime.add(new
	  Employee(mergedTime.get(mergedTime.size()-1).endTime,maxElement)); }
	 
	return listFreeTime;
}

}
class Employee{
	int startTime;
	int endTime;
	Employee(int startTime,int endTime){
		this.startTime = startTime;
		this.endTime = endTime;
	}
	
	@Override
		public String toString()
		{
			// TODO Auto-generated method stub
			return "StartTime:"+this.startTime+"  EndTime:"+this.endTime;
		}
}




