package tesc;

public class ParentChild2
{

}
