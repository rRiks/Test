package tesc;
/*
 * Bharat Navali
 * Naveen Prakash singh
 * Sailesh Meshram
 * Sanchit Agarwal
Imagine we have an image. We'll represent this image as a simple 2D array where every pixel is a 1 or a 0.

The image you get is known to have potentially many distinct rectangles of 0s on a background of 1's. Write a function that takes in the image and returns the coordinates of all the 0 rectangles -- top-left and bottom-right; or top-left, width and height.
int row[][] = {2, 3};
image1 = [
  [0, 1, 1, 1, 1, 1, 1],
  [1, 1, 1, 1, 1, 1, 1],
  [0, 1, 1, 0, 0, 0, 1],
  [1, 0, 1, 0, 0, 0, 1],
  [1, 0, 1, 1, 1, 1, 1],
  [1, 0, 1, 0, 0, 1, 1],
  [1, 1, 1, 0, 0, 1, 1],
  [1, 1, 1, 1, 1, 1, 0],
]

[
  [[0, 0], [0, 0]],
  [[2, 0], [2, 0]],
  [[2, 3], [3, 5]],
  
]

Sample output variations (only one is necessary):

findRectangles(image1) =>
  // (using top-left-row-column and bottom-right):
  [
    [[0,0],[0,0]],
    [[2,0],[2,0]],
    [[2,3],[3,5]],
    [[3,1],[5,1]],
    [[5,3],[6,4]],
    [[7,6],[7,6]],
  ]
  // (using top-left-row-column and width/height):
  [
    [[0,0],[1,1]],
    [[2,0],[1,1]],
    [[2,3],[3,2]],
    [[3,1],[1,3]],
    [[5,3],[2,2]],
    [[7,6],[1,1]],
  ]

Other test cases:

image2 = [
  [0],
]

findRectangles(image2) =>
  // (using top-left-row-column and bottom-right):
  [
    [[0,0],[0,0]],
  ]

  // (using top-left-row-column and width/height):
  [
    [[0,0],[1,1]],
  ]

image3 = [
  [1],
]

findRectangles(image3) => []

image4 = [
  [1, 1, 1, 1, 1],
  [1, 0, 0, 0, 1],
  [1, 0, 0, 0, 1],
  [1, 0, 0, 0, 1],
  [1, 1, 1, 1, 1],
]

findRectangles(image4) =>
  // (using top-left-row-column, and bottom-right or width/height):
  [
    [[1,1],[3,3]],
  ]

n: number of rows in the input image
m: number of columns in the input image
*/

public class FindRectangle2 {
    
  public static void main(String[] argv) {
    int[][] image1 = {
      {0, 1, 1, 1, 1, 1, 1},
      {1, 1, 1, 1, 1, 1, 1},
      {0, 1, 1, 0, 0, 0, 1},
      {1, 0, 1, 0, 0, 0, 1},
      {1, 0, 1, 1, 1, 1, 1},
      {1, 0, 1, 0, 0, 1, 1},
      {1, 1, 1, 0, 0, 1, 1},
      {1, 1, 1, 1, 1, 1, 0},
    };

    int[][] image2 = {
      {0},
    };

    int[][] image3 = {
      {1},
    };

    int[][] image4 = {
      {1, 1, 1, 1, 1},
      {1, 0, 0, 0, 1},
      {1, 0, 0, 0, 1},
      {1, 0, 0, 0, 1},
      {1, 1, 1, 1, 1},
    };


//     int[][] result = getRectangle(image5);
    
//     System.out.println(Arrays.deepToString(result));
  }
  
  public static int[][] getRectangle(int[][] image) {
    int[][] result = new int[2][2];
    
    for (int i = 0 ; i < image.length ; i++) {
      for (int j = 0 ; j < image[i].length ; j++) {
        if (image[i][j] == 0) {
          return getIndexes(image, i, j);
        }
      }
    }
    
    return result;
  } 
  
  public static int[][] getIndexes(int[][] image, int i, int j) {
    int[][] result = new int[2][2];
    result[0][0] = i;
    result[0][1] = j;
    
    //Forward direction
    while ((j + 1) < image[i].length) {
      if (image[i][j + 1] == 0) {
        j += 1;
      } else {
        break;
      }
    }
    
    //downward direction
    while((i + 1) < image.length) {
      if (image[i + 1][j] == 0) {
        i += 1;
      } else {
        break;
      }
    }
    
    result[1][0] = i;
    result[1][1] = j;
    return result;
  }
  
  
}
