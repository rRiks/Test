package tesc;
import java.util.*;

/*

You are working on a logic game made up of a series of puzzles. The first type of puzzle you settle on is "sub-Sudoku", a game where the player has to position the numbers 1..N on an NxN matrix.

Your job is to write a function that, given an NxN matrix, returns true if  every row and column contains the numbers 1..N

The matrix can contain any integer, not just 1..N, and not just positive.

Examples:

[[1, 2, 3],
 [2, 3, 1],
 [3, 1, 2]]         -> True

[[1, 2, 3],
 [1, 2, 3],
 [1, 2, 3]]        -> False

[[1, 1, 1],
 [2, 2, 2],
 [3, 3, 3]]        -> False

[[1000, -1000, 6],
 [   2,     3, 1],
 [   3,     1, 2]] -> False

[[0]]              -> False

[[3, 2, 3, 2],
 [2, 3, 2, 3],
 [3, 2, 3, 2],
 [2, 3, 2, 3]] 	-> False

[[2, 3, 4],
 [3, 4, 2],
 [4, 2, 3]]        -> False

n: The number of rows/columns in the matrix



*/

public class Sudoku {
  public static void main(String[] argv) {
    // True
    int[][] grid1 = {
      {1,2,3},
      {2,3,1},
      {3,1,2}
    };
    // False
    int[][] grid2 = {
      {1,2,3},
      {1,2,3},
      {1,2,3}
    };
    // False
    int[][] grid3 = {
      {1,1,1},
      {2,2,2},
      {3,3,3}
    };
    // False
    int[][] grid4 = {
      {1000,-1000,6},
      {2,3,1},
      {3,1,2}
    };
    // False
    int[][] grid5 = {{0}};
    // False
    int[][] grid6 = {
      {3, 2, 3, 2},
      {2, 3, 2, 3},
      {3, 2, 3, 2},
      {2, 3, 2, 3}
    };
    // False
    int[][] grid7 = {
      {2,3,4},
      {3,4,2},
      {4,2,3}
    };
    System.out.println(checkMat(grid1));
    System.out.println(checkMat(grid2));
    System.out.println(checkMat(grid3));
    System.out.println(checkMat(grid4));
    System.out.println(checkMat(grid5));
    System.out.println(checkMat(grid6));
    System.out.println(checkMat(grid7));

  }
  public static boolean checkMat(int[][] mat) {
	    //traverse the rows
	    boolean result = true;
	    List<Integer> list = new ArrayList<>();
	    for (int i = 1; i <= mat.length; i++){
	      list.add(i);
	    }
	    
	    List<Integer> l2 = new ArrayList<>();
	    int col=0, row =0;
	    
	    for ( row = 0; row< mat.length; row++) {
	      l2.clear();
	      for ( col = 0 ; col < mat[0].length; col++) {
	             l2.add(mat[row][col]); 
	      }
	      Collections.sort(l2);
	      //System.out.println("l2 :" + l2.toString());
	      for ( col = 0 ; col < mat[0].length; col++){
	        if (l2.get(col) != list.get(col)) {
				/*
				 * System.out.println("failing here  l2.get(col) : " + l2.get(col) + "  list.get(col) " +
				 * list.get(col) + " col = " + col);
				 */
	          result = false;
	          return result;
	        }
	      }
	    }
	    
	    
	  for ( col = 0 ; col < mat[0].length; col++) {
	    l2.clear();
	    for ( row = 0; row< mat.length; row++) {
	      l2.add(mat[row][col]);
	    }
	    Collections.sort(l2);
		/* System.out.println("l2-second :" + l2.toString()); */
	    
	    for ( col = 0 ; col < mat[0].length; col++){
	        if (l2.get(col) != list.get(col)) {
				/*
				 * System.out.println("second-failing here  l2.get(col) : " + l2.get(col) +
				 * "  list.get(col) " + list.get(col) + " col = " + col);
				 */
	          result = false;
	          return result;
	        }
	      }
	  }
	   return result; 
	  }
 }


