package tesc;
/*
You are in charge of a display advertising program. Your ads are displayed on websites all over the internet. 
You have some CSV input data that counts how many times that users have clicked on an ad on each individual domain. 
Every line consists of a click count and a domain name, like this:

counts = [ "900,google.com",
     "60,mail.yahoo.com",
     "10,mobile.sports.yahoo.com",
     "40,sports.yahoo.com",
     "300,yahoo.com",
     "10,stackoverflow.com",
     "20,overflow.com",
     "5,com.com",
     "2,en.wikipedia.org",
     "1,m.wikipedia.org",
     "1,mobile.sports",
     "1,google.co.uk"]

Write a function that takes this input as a parameter and returns a data structure containing the number of 
clicks that were recorded on each domain AND each subdomain under it. For example, a click on "mail.yahoo.com" counts toward the totals for "mail.yahoo.com",
 "yahoo.com", and "com". (Subdomains are added to the left of their parent domain. So "mail" and "mail.yahoo" are not valid domains. Note that "mobile.sports" appears as a separate domain near the bottom of the input.)

Sample output (in any order/format):

calculateClicksByDomain(counts) =>
com:                     1345
google.com:              900
stackoverflow.com:       10
overflow.com:            20
yahoo.com:               410
mail.yahoo.com:          60
mobile.sports.yahoo.com: 10
sports.yahoo.com:        50
com.com:                 5
org:                     3
wikipedia.org:           3
en.wikipedia.org:        2
m.wikipedia.org:         1
mobile.sports:           1
sports:                  1
uk:                      1
co.uk:                   1
google.co.uk:            1

n: number of domains in the input
(individual domains and subdomains have a constant upper length)

*/
/*2nd
 * We have some clickstream data that we gathered on our client's website. Using cookies, we collected snippets of users' anonymized URL histories while they browsed the site. The histories are in order and consist of unique URLs.

Write a function that takes two user�s browsing histories as input and returns the longest common string of URLs that appears in both.
 *
 *3rd 
 *The people who buy ads on our network don't have enough data about how ads are working for their business. They've asked us to find out which ads produce the most purchases on their website.

Write code to parse this data, determine how many times each ad was clicked, then determine how many of those ad clicks were from users who made a purchase.
 */
import java.io.*;
import java.util.*;
public class DomainCount
{

	public static void main(String[] args)
	{
		String[] counts = {"900,google.com",
                "60,mail.yahoo.com",
                "10,mobile.sports.yahoo.com",
                "40,sports.yahoo.com",
                "300,yahoo.com",
                "10,stackoverflow.com",
                "20,overflow.com",
                "5,com.com",
                "2,en.wikipedia.org",
                "1,m.wikipedia.org",
                "1,mobile.sports",
                "1,google.co.uk"};
		
		Map<String,Integer> domainMap =  getDomainCount(counts);
		System.out.println(domainMap);
		/*
		 * for(Map.Entry<String, Integer> entry:domainMap.entrySet()) {
		 * System.out.println(entry.getKey()+":    "+entry.getValue()); }
		 */
		
	}
	public static Map<String,Integer> getDomainCount(String[] domainCount){
		Map<String,Integer> domainMap = new HashMap<String,Integer>();
		for(String strDomain:domainCount) {
			String []domainArr = strDomain.split("\\,");
			int domainCountVal = Integer.valueOf(domainArr[0]);
			String []domainSplit = domainArr[1].split("\\.");
			StringBuilder domainBuilder = new StringBuilder();
			for(int count = domainSplit.length-1;count>-1;count--) {
				if(count!=domainSplit.length-1) {
					domainBuilder.insert(0,".");
				}
				domainBuilder.insert(0,domainSplit[count]);
				domainMap.put(domainBuilder.toString(),domainMap.getOrDefault(domainBuilder.toString(), 0)+domainCountVal);
			}
		}
		return domainMap;
	}
	
}
