package tesc;

/*
We have some clickstream data that we gathered on our client's website. Using cookies, we collected snippets of users' anonymized URL histories while they browsed the site. The histories are in chronological order, and no URL was visited more than once per person.

Write a function that takes two users' browsing histories as input and returns the longest contiguous sequence of URLs that appears in both.

Sample input:

user0 = ["/start", "/green", "/blue", "/pink", "/register", "/orange", "/one/two"]
user1 = ["/start", "/pink", "/register", "/orange", "/red", "a"]
user2 = ["a", "/one", "/two"]
user3 = ["/pink", "/orange", "/yellow", "/plum", "/blue", "/tan", "/red", "/amber", "/HotRodPink", "/CornflowerBlue", "/LightGoldenRodYellow", "/BritishRacingGreen"]
user4 = ["/pink", "/orange", "/amber", "/BritishRacingGreen", "/plum", "/blue", "/tan", "/red", "/lavender", "/HotRodPink", "/CornflowerBlue", "/LightGoldenRodYellow"]
user5 = ["a"]
user6 = ["/pink","/orange","/six","/plum","/seven","/tan","/red", "/amber"]

Sample output:

findContiguousHistory(user0, user1) => ["/pink", "/register", "/orange"]
findContiguousHistory(user0, user2) => [] (empty)
findContiguousHistory(user0, user0) => ["/start", "/green", "/blue", "/pink", "/register", "/orange", "/one/two"]
findContiguousHistory(user2, user1) => ["a"] 
findContiguousHistory(user5, user2) => ["a"]
findContiguousHistory(user3, user4) => ["/plum", "/blue", "/tan", "/red"]
findContiguousHistory(user4, user3) => ["/plum", "/blue", "/tan", "/red"]
findContiguousHistory(user3, user6) => ["/tan", "/red", "/amber"]

n: length of the first user's browsing history
m: length of the second user's browsing history
*/

import java.io.*;
import java.util.*;

public class DomainCount1 {
	
	public static void main(String[] args)
	{
		  
	    String[] user0 = {"/start", "/green", "/blue", "/pink", "/register", "/orange", "/one/two"};
	    String[] user1 = {"/start", "/pink", "/register", "/orange", "/red", "a"};
	    String[] user2 = {"a", "/one", "/two"};
	    String[] user3 = {"/pink", "/orange", "/yellow", "/plum", "/blue", "/tan", "/red", "/amber", "/HotRodPink", "/CornflowerBlue", "/LightGoldenRodYellow", "/BritishRacingGreen"};
	    String[] user4 = {"/pink", "/orange", "/amber", "/BritishRacingGreen", "/plum", "/blue", "/tan", "/red", "/lavender", "/HotRodPink", "/CornflowerBlue", "/LightGoldenRodYellow"};
	    String[] user5 = {"a"};
	    String[] user6 = {"/pink","/orange","/six","/plum","/seven","/tan","/red", "/amber"};
	  
	    String[] sArr = calculateClicksByDomain(user0, user1);
	    
	    for(String s : sArr){
	      System.out.println(s);
	    }
	  }
	  
	  public static String[] calculateClicksByDomain(String[] user1, String[] user2){
	    
	    if(user1.length < user2.length){
	      // process user1
	    	return  helper(user1, user2);
	    } else {
	      // process user2
	    	return helper(user2, user1);
	    }
	  }
	  
	  public static String[] helper(String[] user1, String[] user2){
	    List<String> res = new ArrayList<>();
	    
	    List<String> currRes = new ArrayList<>();
	    int lastMatch = -1;
	    for(String s : user1){
	      for(int i=0;i<user2.length;i++){
	        if(s.equals(user2[i])){
	          if(lastMatch+1!=i){
	            currRes = new ArrayList<>();
	          }
	          currRes.add(s);
	          if(currRes.size() > res.size()){
	            res = currRes;
	          }
	          lastMatch=i;
	          break;
	        }
	      }
	    }
	    return res.toArray(new String[0]); 
	  }
	  
	}
